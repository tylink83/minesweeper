//
//  minesweeper_2_0App.swift
//  minesweeper 2.0
//
//  Created by Link, Ty - Student on 12/10/24.
//

import SwiftUI

@main
struct minesweeper_2_0App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
